# 拇指王数字门玩法演示 · 可扩展 Godot 白模

这是一个 Godot 4.x 的模块化白模，当前只启用弓手，用来验证：

- 玩家从右侧主路移动到左路收集弓手数字门。
- 弓手部件独立累计，5 个部件完成 1 名弓手。
- 数字门部件溢出保留到下一名弓手。
- 完成的弓手加入主路后排，自动锁定史莱姆发射箭矢。
- 史莱姆由 12 个独立拼豆格组成，受击时按外围到中心销毁。

## 运行

用 Godot 4.x 导入本目录，运行 `main.tscn`。使用 `A/D` 或左右方向键移动。

## 扩展入口

### 新职业

1. 在 `scripts/` 下新增 `shield_guard_role.gd` 或 `mage_role.gd`。
2. 继承 `RoleBehavior`，实现 `tick_role()`、`receive_damage()` 或完成技能。
3. 在 `role_factory.gd` 的 `switch` 中注册脚本。
4. 在 `game.gd` 的 `role_definitions` 中增加 `RoleDefinition` 配置。

### 新攻击方式

- 弓手攻击：`archer_role.gd` 的 `tick_role()`。
- 子弹移动和命中：`projectile.gd` 与 `game.gd` 的 `update_projectiles()`。
- 新武器可以新增 `Projectile` 子类，或让 `RoleBehavior` 发出不同的攻击信号。

### 新敌人

继承一个敌人基类，至少提供 `lane`、`z_depth`、`hp`、`take_hit()` 和 `tick()`，再在 `game.gd` 的敌人列表中注册。

### 新数字门

`gate.gd` 只负责显示和空间移动；门的结算统一交给 `role_assembly_system.gd`。因此以后增加负门、随机职业门、集装箱分裂门时，不需要把结算逻辑写进角色脚本。

### 局内数据和商店

`run_state.gd` 负责保存部件进度、完成角色、驻场角色、羁绊刻印、货币和职业权重。以后接商店时，让商店修改 `role_spawn_weights`，不要直接修改角色攻击力。

## 代码边界

`game.gd` 只负责场景编排和坐标换算；`RoleAssemblySystem` 负责部件到完整角色的转换；`RoleBehavior` 负责职业行为；`SlimeEnemy` 负责敌人自身生命和拼豆破坏；`Projectile` 负责弹道实体。正式项目可以把这些脚本进一步替换为独立场景和资源配置。
