class_name ArcherRole
extends RoleBehavior

var attack_interval := 0.75
var attack_timer := 0.0

func setup(role_definition: RoleDefinition) -> void:
	super.setup(role_definition)
	attack_interval = 0.75

func tick_role(delta: float, targets: Array) -> void:
	attack_timer -= delta
	if attack_timer > 0.0:
		return
	var target = nearest_target(targets)
	if target == null:
		return
	attack_timer = attack_interval
	fire_requested.emit(target.lane, 1, self)

func nearest_target(targets: Array):
	var best = null
	for target in targets:
		if target == null or target.hp <= 0:
			continue
		if best == null or target.z_depth > best.z_depth:
			best = target
	return best

func _draw() -> void:
	super._draw()
	draw_line(Vector2(17, -28), Vector2(31, -18), Color("#75bd5a"), 5.0)
	draw_line(Vector2(31, -18), Vector2(17, -8), Color("#75bd5a"), 3.0)
	draw_circle(Vector2(0, -47), 8.0, Color("#77bf64"))
