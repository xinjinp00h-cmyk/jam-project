extends Node2D

const VIEW := Vector2(450, 700)
const HORIZON := 225.0
const RunStateScript = preload("res://scripts/run_state.gd")
const AssemblyScript = preload("res://scripts/role_assembly_system.gd")
const RoleFactoryScript = preload("res://scripts/role_factory.gd")
const GateScript = preload("res://scripts/gate.gd")
const SlimeScript = preload("res://scripts/slime_enemy.gd")
const ProjectileScript = preload("res://scripts/projectile.gd")
const ArcherDefinition = preload("res://data/roles/archer.tres")

var font: Font
var state: RunState
var assembly: RoleAssemblySystem
var role_definitions: Dictionary = {}
var gates: Array[NumberGate] = []
var slimes: Array[SlimeEnemy] = []
var projectiles: Array[Projectile] = []
var active_roles: Array[RoleBehavior] = []
var lane := 2
var gate_timer := 0.0
var slime_timer := 0.0
var last_gate_message := "移动到左路收集弓手部件"

func _ready() -> void:
	font = ThemeDB.fallback_font
	state = RunStateScript.new()
	role_definitions["archer"] = ArcherDefinition
	assembly = AssemblyScript.new()
	add_child(assembly)
	assembly.setup(state, role_definitions)
	assembly.role_completed.connect(_on_role_completed)
	assembly.progress_changed.connect(_on_progress_changed)
	queue_redraw()

func make_role_definition(id: String, title: String, action: String, persistence: String, hp: int) -> RoleDefinition:
	var definition := RoleDefinition.new()
	definition.role_id = id
	definition.role_name = title
	definition.completion_action = action
	definition.persist_type = persistence
	definition.base_hp = hp
	return definition

func _process(delta: float) -> void:
	var direction := Input.get_axis("move_left", "move_right")
	if direction != 0.0:
		lane = clampi(lane + int(sign(direction)), 0, 2)
	gate_timer += delta
	slime_timer += delta
	if gate_timer >= 0.70:
		gate_timer = 0.0
		spawn_gate()
	if slime_timer >= 2.8:
		slime_timer = 0.0
		spawn_slime()
	update_gates(delta)
	update_slimes(delta)
	update_roles(delta)
	update_projectiles(delta)
	queue_redraw()

func spawn_gate() -> void:
	var gate: NumberGate = GateScript.new()
	gate.setup("archer", 1)
	add_child(gate)
	gates.append(gate)
	place_depth_node(gate, 0.02, 0)

func spawn_slime() -> void:
	var slime: SlimeEnemy = SlimeScript.new()
	add_child(slime)
	slimes.append(slime)
	place_depth_node(slime, slime.z_depth, 2)

func update_gates(delta: float) -> void:
	for gate in gates:
		gate.z_depth += delta * 0.13
		place_depth_node(gate, gate.z_depth, 0)
		if not gate.collected and gate.z_depth >= 0.88 and lane == 0:
			gate.collected = true
			assembly.apply_gate(gate.role_id, gate.part_value)
			last_gate_message = "获得弓手部件"
	for gate in gates.duplicate():
		if gate.z_depth > 1.1:
			gates.erase(gate)
			gate.queue_free()

func update_slimes(delta: float) -> void:
	for slime in slimes:
		slime.tick(delta)
		place_depth_node(slime, slime.z_depth, 2)
	for slime in slimes.duplicate():
		if slime.z_depth > 1.05 or slime.hp <= 0:
			slimes.erase(slime)
			slime.queue_free()

func update_roles(delta: float) -> void:
	for i in active_roles.size():
		var role := active_roles[i]
		role.position = Vector2(world_x(2, 1.0) + (i - (active_roles.size() - 1) / 2.0) * 58.0, 650)
		role.tick_role(delta, slimes)

func update_projectiles(delta: float) -> void:
	for projectile in projectiles:
		projectile.tick(delta)
		projectile.position = Vector2(world_x(projectile.lane, projectile.z_depth), world_y(projectile.z_depth))
		for slime in slimes:
			if projectile.get_meta("used", false):
				continue
			if absf(projectile.z_depth - slime.z_depth) < 0.045 and projectile.lane == slime.lane:
				projectile.set_meta("used", true)
				slime.take_hit(projectile.damage)
	for projectile in projectiles.duplicate():
		if projectile.z_depth <= 0.0 or projectile.get_meta("used", false):
			projectiles.erase(projectile)
			projectile.queue_free()

func _on_role_completed(role_id: String) -> void:
	var role := RoleFactoryScript.create_role(role_id)
	role.setup(role_definitions[role_id])
	role.fire_requested.connect(_on_fire_requested)
	add_child(role)
	active_roles.append(role)
	last_gate_message = "弓手完成，加入后排"

func _on_progress_changed(role_id: String, progress: int, completed: int) -> void:
	last_gate_message = "%s：%d/5，已完成 %d 名" % [role_definitions[role_id].role_name, progress, completed]

func _on_fire_requested(target_lane: int, damage: int, _source: RoleBehavior) -> void:
	var projectile: Projectile = ProjectileScript.new()
	projectile.setup(target_lane, damage)
	add_child(projectile)
	projectiles.append(projectile)
	projectile.position = Vector2(world_x(target_lane, projectile.z_depth), world_y(projectile.z_depth))

func world_x(which_lane: int, z: float) -> float:
	return VIEW.x / 2.0 + float(which_lane - 1) * lerpf(35.0, 180.0, z)

func world_y(z: float) -> float:
	return HORIZON + z * 425.0

func place_depth_node(node: Node2D, z: float, which_lane: int) -> void:
	node.position = Vector2(world_x(which_lane, z), world_y(z))
	node.z_index = int(z * 100.0)

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, VIEW), Color("#84958b"))
	draw_rect(Rect2(0, HORIZON - 28, VIEW.x, 28), Color("#52645e"))
	for i in 3:
		draw_line(Vector2(VIEW.x / 2.0, HORIZON), Vector2(i * 180.0 + 45.0, VIEW.y), Color("#d9a55a88"), 2.0)
	for z in [0.18, 0.34, 0.50, 0.66, 0.82, 0.98]:
		draw_line(Vector2(world_x(0, z), world_y(z)), Vector2(world_x(2, z), world_y(z)), Color("#ffffff33"), 2.0)
	draw_circle(Vector2(world_x(lane, 1.0), 650), 8.0, Color("#ffd66b"))
	draw_string(font, Vector2(14, 28), "拇指王数字门 · 可扩展白模", HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color.WHITE)
	draw_string(font, Vector2(14, 49), "左路收集弓手门 · 主路自动防守", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#e5eadf"))
	draw_string(font, Vector2(14, 680), last_gate_message, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#ffe49a"))
	draw_string(font, Vector2(350, 28), "弓手 %d" % active_roles.size(), HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color("#75bd5a"))
