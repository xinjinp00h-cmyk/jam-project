class_name NumberGate
extends Node2D

var z_depth := 0.02
var role_id := "archer"
var part_value := 1
var collected := false
var lane := 0
var accent := Color("#75bd5a")

func setup(next_role_id: String, next_part_value: int) -> void:
	role_id = next_role_id
	part_value = next_part_value
	accent = Color("#75bd5a") if role_id == "archer" else Color("#d95845")
	queue_redraw()

func _draw() -> void:
	var width := lerpf(30.0, 150.0, z_depth)
	var height := lerpf(16.0, 50.0, z_depth)
	draw_rect(Rect2(Vector2(-width / 2.0, -height / 2.0), Vector2(width, height)), Color("#287bc5"))
	draw_rect(Rect2(Vector2(-width / 2.0, -height / 2.0), Vector2(width, height)), accent, false, 3.0)
	draw_string(ThemeDB.fallback_font, Vector2(-width * 0.25, 6), "%s +%d" % [role_id.capitalize(), part_value], HORIZONTAL_ALIGNMENT_LEFT, -1, maxf(10.0, 12.0 + z_depth * 8.0), Color.WHITE)
