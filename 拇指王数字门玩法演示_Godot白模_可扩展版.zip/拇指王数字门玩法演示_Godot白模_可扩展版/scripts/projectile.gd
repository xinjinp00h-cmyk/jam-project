class_name Projectile
extends Node2D

var z_depth := 0.88
var lane := 2
var damage := 1
var speed := 0.70

func setup(next_lane: int, next_damage: int = 1) -> void:
	lane = next_lane
	damage = next_damage

func tick(delta: float) -> void:
	z_depth -= speed * delta
	queue_redraw()

func _draw() -> void:
	draw_line(Vector2(0, 18), Vector2.ZERO, Color("#ffe49a"), 3.0)
	draw_circle(Vector2.ZERO, 4.0, Color("#ffd66b"))
