class_name RoleAssemblySystem
extends Node

signal role_completed(role_id: String)
signal progress_changed(role_id: String, progress: int, completed: int)

var state: RunState
var definitions: Dictionary = {}

func setup(next_state: RunState, role_definitions: Dictionary) -> void:
	state = next_state
	definitions = role_definitions
	for role_id in definitions:
		state.ensure_role(role_id)

func apply_gate(role_id: String, part_value: int) -> void:
	if state == null or not definitions.has(role_id):
		return
	var definition: RoleDefinition = definitions[role_id]
	var total: int = state.role_progress[role_id] + maxi(part_value, 0)
	var completed: int = total / definition.required_parts
	state.role_progress[role_id] = total % definition.required_parts
	state.completed_role_count[role_id] += completed
	state.bond_stamps[role_id] += completed
	progress_changed.emit(role_id, state.role_progress[role_id], state.completed_role_count[role_id])
	for i in completed:
		state.active_roles.append({"role_id": role_id, "hp": definition.base_hp})
		role_completed.emit(role_id)
