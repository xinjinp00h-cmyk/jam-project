class_name RoleBehavior
extends Node2D

signal fire_requested(lane: int, damage: int, source: RoleBehavior)
signal skill_requested(skill_name: String, source: RoleBehavior)

var role_id: String = ""
var display_name: String = ""
var hp: int = 1
var lane: int = 2

func setup(role_definition: RoleDefinition) -> void:
	role_id = role_definition.role_id
	display_name = role_definition.role_name
	hp = role_definition.base_hp
	queue_redraw()

func tick_role(_delta: float, _targets: Array) -> void:
	pass

func receive_damage(amount: int) -> void:
	hp -= amount
	if hp <= 0:
		queue_free()

func _draw() -> void:
	draw_circle(Vector2(0, -28), 18.0, Color("#f0e6d0"))
	draw_circle(Vector2(0, -28), 18.0, Color("#202827"), false, 3.0)
