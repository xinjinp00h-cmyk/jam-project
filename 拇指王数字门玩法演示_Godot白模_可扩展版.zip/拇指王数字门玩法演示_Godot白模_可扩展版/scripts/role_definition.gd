class_name RoleDefinition
extends Resource

@export var role_id: String = "archer"
@export var role_name: String = "弓手"
@export var required_parts: int = 5
@export var completion_action: String = "join_queue"
@export var persist_type: String = "persistent"
@export var skill_multiplier: float = 1.0
@export var base_hp: int = 10
@export var bond_id: String = "archer"
@export var visual_set_id: String = "archer_basic"
