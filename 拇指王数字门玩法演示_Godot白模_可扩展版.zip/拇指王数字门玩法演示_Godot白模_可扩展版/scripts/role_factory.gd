class_name RoleFactory
extends RefCounted

const ARCHER_SCRIPT = preload("res://scripts/archer_role.gd")
const WARRIOR_SCRIPT = preload("res://scripts/warrior_role.gd")

static func create_role(role_id: String) -> RoleBehavior:
	var role: RoleBehavior
	switch role_id:
		"archer":
			role = ARCHER_SCRIPT.new()
		"warrior":
			role = WARRIOR_SCRIPT.new()
		_:
			role = RoleBehavior.new()
	return role
