class_name RunState
extends RefCounted

var currency: int = 0
var role_progress: Dictionary = {}
var completed_role_count: Dictionary = {}
var active_roles: Array = []
var bond_stamps: Dictionary = {}
var role_spawn_weights: Dictionary = {}

func register_role(role_id: String, starting_weight: float = 25.0) -> void:
	role_progress[role_id] = 0
	completed_role_count[role_id] = 0
	bond_stamps[role_id] = 0
	role_spawn_weights[role_id] = starting_weight

func ensure_role(role_id: String) -> void:
	if not role_progress.has(role_id):
		register_role(role_id)
