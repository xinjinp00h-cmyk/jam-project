class_name SlimeEnemy
extends Node2D

const CELLS := [
	Vector2(0.50, 0.08), Vector2(0.28, 0.28), Vector2(0.50, 0.28), Vector2(0.72, 0.28),
	Vector2(0.13, 0.51), Vector2(0.36, 0.51), Vector2(0.57, 0.51), Vector2(0.87, 0.51),
	Vector2(0.20, 0.76), Vector2(0.40, 0.76), Vector2(0.60, 0.76), Vector2(0.80, 0.76)
]
const DESTROY_ORDER := [4, 7, 8, 11, 0, 3, 9, 10, 1, 2, 5, 6]

var z_depth := 0.03
var hp := 12
var holes: Array[int] = []
var flash := 0.0
var lane := 2

func tick(delta: float) -> void:
	z_depth += delta * 0.09
	flash = maxf(0.0, flash - delta)
	queue_redraw()

func take_hit(damage: int = 1) -> Dictionary:
	if hp <= 0:
		return {}
	for cell_id in DESTROY_ORDER:
		if not holes.has(cell_id):
			holes.append(cell_id)
			hp -= damage
			flash = 0.12
			queue_redraw()
			return {"cell_id": cell_id, "destroyed": hp <= 0}
	return {}

func _draw() -> void:
	var size := 70.0 * (0.25 + z_depth * 1.2)
	for i in CELLS.size():
		if holes.has(i):
			continue
		var point := Vector2((CELLS[i].x * 2.0 - 1.0) * size, (CELLS[i].y - 0.45) * size * 1.65)
		var cell_size := maxf(7.0, size * 0.27)
		var color := Color("#ffffff") if flash > 0.0 else Color("#1476e8")
		draw_rect(Rect2(point - Vector2(cell_size / 2.0, cell_size / 2.0), Vector2(cell_size, cell_size)), color)
		draw_rect(Rect2(point - Vector2(cell_size / 2.0, cell_size / 2.0), Vector2(cell_size, cell_size)), Color("#5fd5ff"), false, 1.0)
