class_name WarriorRole
extends RoleBehavior

signal consumed_after_charge

var state := "charge_ready"
var timer := 0.0

func tick_role(delta: float, _targets: Array) -> void:
	timer += delta
	if state == "charge_ready" and timer >= 0.25:
		state = "charging"
		timer = 0.0
		skill_requested.emit("warrior_charge", self)
	elif state == "charging" and timer >= 0.35:
		state = "consumed"
		consumed_after_charge.emit()
		queue_free()

func _draw() -> void:
	super._draw()
	draw_line(Vector2(-15, -48), Vector2(0, -58), Color("#d95845"), 6.0)
	draw_line(Vector2(0, -58), Vector2(15, -48), Color("#d95845"), 6.0)
